package modele;

public class LoginBean {
    
    // 1. Les attributs privés demandés
    private String nom;
    private String password;

    // 2. Le constructeur vide (toujours obligatoire pour un JavaBean)
    public LoginBean() {
    }

    // 3. Les Getters et Setters pour accéder aux attributs
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}