<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ page import="java.util.List" %>
<%@ page import="modele.LoginBean" %>
<!DOCTYPE html>
<html>
<head><title>Gestion des Utilisateurs</title></head>
<body>
    <h2>Ajouter un utilisateur</h2>
    <!-- Ce formulaire pointe vers la Servlet Ajouter -->
    <form action="Ajouter" method="POST">
        Nom: <input type="text" name="nom" required>
        Mot de passe: <input type="text" name="password" required>
        <button type="submit">Ajouter</button>
    </form>

    <hr>
    <h2>Liste des utilisateurs</h2>
    <table border="1">
        <tr>
            <th>Nom</th>
            <th>Mot de passe</th>
            <th>Action</th>
        </tr>
        <%
            // On récupère la liste envoyée par le contrôleur Debut
            List<LoginBean> liste = (List<LoginBean>) request.getAttribute("listeUsers");
            if (liste != null) {
                for (LoginBean user : liste) {
        %>
        <tr>
            <td><%= user.getNom() %></td>
            <td><%= user.getPassword() %></td>
            <td>
                <!-- Ce bouton pointe vers la Servlet Supprimer -->
                <form action="Supprimer" method="POST" style="margin:0;">
                    <input type="hidden" name="nomASupprimer" value="<%= user.getNom() %>">
                    <button type="submit">Supprimer</button>
                </form>
            </td>
        </tr>
        <%
                }
            }
        %>
    </table>
</body>
</html>